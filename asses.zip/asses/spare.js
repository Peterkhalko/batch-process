const { ObjectId } = require("bson");
const purchaseOrderModel = require("../models/purchaseorder");
const productModel = require("../models/product");
const db = require('../config/dbConnection')
const mongoose = require('mongoose')
const purchaseOrderService = {
  createOrders: async (req, res) => {
    const result = {};
    const orderMap = req.body;
    const ordersDataSets = [];
    const ordersRejectedDataSets = [];
    const ordersInsertedLookupDataSets = [];
    const ordersRejectedLookupDataSets = [];
    const modelResponse = [];
    const session = await mongoose.startSession();
    session.startTransaction();
    try {
    
      // Step 2: Optional. Define options to use for the transaction

      if (!Array.isArray(orderMap) || orderMap.length === 0) {
        result.status = 400;
        result.message = "found empty orders!";
        return result;
      }
      for (const order of orderMap) {
        if (!order.categoryid) {
          result.status = 400;
          result.message = "category name not provided!";
          throw result;
        }
        if (!order.createdby) {
          result.status = 400;
          result.message = "createdby is not provided!";
          throw result;
        }
        if (!order.quantity) {
          result.status = 400;
          result.message = "quantity is not provided!";
          throw result;
        }
        if (!order.productid) {
          result.status = 400;
          result.message = "productid is not provided!";
          throw result;
        }
        //implementing transactions to perform mult.iple operations as a single, atomic unit.
        // If any part of the transaction fails,
        //all changes made   the transaction can be rolled back
        // const session = await mongoose.startSession();
        // session.startTransaction();
        const transactionOptions = {
          readPreference: 'primary',
          readConcern: { level: 'local' },
          writeConcern: { w: 'majority' }
        };

        // await session.withTransaction(async () => {
          const productAvailibilityCheck = await productModel.findById(
            new ObjectId(order.productid)
          );
          console.log("productAvailibilityCheck----------",productAvailibilityCheck)
          if (
            productAvailibilityCheck &&
            productAvailibilityCheck.quantity >= order.quantity
          ) {
           const productModelResponse =  await productModel.findOneAndUpdate(
              { _id: new ObjectId(order.productid) }, // Filter criteria
              { $inc: { quantity: -order.quantity } }, // Update operation
              { new:true,session} // Options including the session
            );
          
             console.log(":findOneAndUpdate Response",productModelResponse)
            const payload = {
              categoryid: new ObjectId(order.categoryid),
              productid: order.productid,
              quantity: order.quantity,
              createdby: new ObjectId(order.createdby),
            };
            ordersDataSets.push(payload);
            const purchaseOrderModelRsponse = await purchaseOrderModel.create([payload],{session});
            console.log("order placed reponse",purchaseOrderModelRsponse);
            modelResponse.push(purchaseOrderModelRsponse);
            await session.commitTransaction();
          } else {
            ordersRejectedDataSets.push(order);
          }
        // },transactionOptions)
      }

        // const modelResponse = await purchaseOrderModel.methods.createOrders(
        //   ordersDataSets
        // );
        console.log("ordersRejectedDataSets",ordersRejectedDataSets);
        console.log("modelResponse",modelResponse)
      if (ordersRejectedDataSets.length > 0) {
        for (const order of ordersRejectedDataSets) {
          req.body.customquery = { _id: new ObjectId(order.productid) };
          const response = await productModel.methods.getProduct(req, res);
          ordersRejectedLookupDataSets.push(...response);
        }
      }
      if (modelResponse.length > 0) {
        for (const order of modelResponse) {
          req.body.customquery = { _id: new ObjectId(order._id) };
          const response = await purchaseOrderModel.methods.getOrders(req, res);
          ordersInsertedLookupDataSets.push(...response);
        }
        result.status = 200;
        (result.message = "oreder created successfully!"),
          (result.data = ordersInsertedLookupDataSets);
        result.rejected = ordersRejectedLookupDataSets;
        return result;
      } else {
        result.status = 200;
        (result.message = "unable to create orders"),
          (result.data = modelResponse);
        result.failure = ordersRejectedLookupDataSets;
        return result;
      }
    } catch (error) {
      console.log("error formed Peter- ", error);
      result.status = 500;
      result.data = `error message : ${error.message}`;
      result.message = `something went bad!`;
      return result;
    }finally{
    
    const x =  (await session).endSession();
    console.log("in the finally closing session",x)
    }   
  },
  getOrders: async (req, res) => {
    const result = {};
    try {
      const modelResponse = await purchaseOrderModel.methods.getOrders(req, res);
      if (modelResponse.length > 0) {
        result.status = 200;
        (result.message = "orders fetched successfully!"),
          (result.data = modelResponse);
        result.count = modelResponse.length;

        return result;
      } else {
        result.status = 200;
        (result.message = "No orders fetched!"),
          (result.data = modelResponse);
        result.count = modelResponse.length;
        return result;
      }
    } catch (error) {
      result.status = 500;
      result.message = `something went bad!`;
      result.data = `error message : ${error.message}`;
      return result;
    }
  },
};
module.exports = purchaseOrderService;
