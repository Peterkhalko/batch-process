const { ObjectId } = require("bson");
const mongoose = require("mongoose");
const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: true,
      unique: true,
    },
    userrole: {
      type: String,
      required: true,

      validate: {
        validator: function (v) {
          return v === 'admin' || v === 'customer';
        },
        message: props => `${props.value} is not a valid user role. Must be 'admin' or 'customer'.`
      }

    },
  },
  {
    timestamps: true,
  }
);

const methods = {
  addUser: async (req, res) => {
    const payload = {
      username: req.body.username,
      userrole: req.body.userrole,
    };
    const data = await user.create(payload);
    return data;
  },
};
const user = mongoose.model("Users", userSchema);
module.exports = user;
module.exports.methods = methods;
