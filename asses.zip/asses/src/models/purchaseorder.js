const mongoose = require("mongoose");
const dayjs = require("dayjs");
const { ObjectId } = require("bson");
const purchaseOrderSchema = new mongoose.Schema(
  {
    createdby: {
      type: ObjectId,
      required: true,
    },
    categoryid: {
      type: ObjectId,
      required: true,
      ref: "Categories",
    },
    status: {
      type: String,
      default: "new",
      validate: {
        validator: function (v) {
          return v === 'new' || v === 'intransit' || 'delivered';
        },
        message: props => `${props.value} is not a valid status. Must be 'new' or 'intrasit' || 'delivered'.`
      }
    },
    productid: {
      type: ObjectId,
      required: true,
    },
    quantity: {
      type: Number,
      required: true,
    },
  },
  {
    timestamps: true,
  },
);

const methods = {
  getOrders: async (req, ref) => {
    const query = [];
    let stagedQuery = {};
    const stage = [];
    if (req.body.id) {
      query.push({ _id: new ObjectId(req.body.id) });
    }
    if (req.body.categoryid) {
      query.push({ category: new ObjectId(req.body.category) });
    }
    if (req.body.status) {
      query.push({ status: req.body.status });
    }
    if (req.body.createdby) {
      query.push({ createdby: new ObjectId(req.body.createdby) });
    }
    if (req.body.productid) {
      query.push({ productid: new ObjectId(req.body.productid) });
    }
    if (req.body.quantity) {
      query.push({ quantity: req.body.quantity });
    }
    if (req.body.customquery) {
      query.push(req.body.customquery);
    }
    if (query.length > 0) {
      stagedQuery.$or = query;
    } else {
      stagedQuery = {};
    }
    stage.push({ $match: stagedQuery });
    stage.push({
      $lookup: {
        from: "products",
        localField: "productid",
        foreignField: "_id",
        as: "productDetails",
      },
    });
    stage.push({
      $lookup: {
        from: "categories",
        localField: "categoryid",
        foreignField: "_id",
        as: "categoryDetails",
      },
    });
    stage.push({
      $lookup: {
        from: "users",
        localField: "createdby",
        foreignField: "_id",
        as: "userDetails",
      },
    });
    stage.push({
      $project: {
        createdby: 0,
        category: 0,
        productid: 0,
      },
    });
    if (req.body.skip) {
      stage.push({ $skip: Number(req.body.skip) });
    }
    if (req.body.limit) {
      stage.push({ $limit: Number(req.body.limit) });
    }
    console.log("stage", stage)
    const data = await purchaseOrder.aggregate(stage);
    return data;
  },
  createOrders: async (ordersDataSets) => {
    const data = await purchaseOrder.create(ordersDataSets);
    return data;
  },
  updateOrders: async (req, res) => {
    const order = await purchaseOrder.findById({ _id: new ObjectId(req.params.orderid) });
    if (!order) {
      return "Order not found"; // Or appropriate error handling
    }
    if (order.status === req.params.status) {
      throw new Error(`Order already has status '${req.params.status}'`);
    } else {
      const data = await purchaseOrder.findByIdAndUpdate(
        { _id: new ObjectId(req.params.orderid) },
        { $set: { status: req.params.status } },
        { new: true }
      );
      return data;
    }


  },
};
const purchaseOrder = mongoose.model("Purchaseorders", purchaseOrderSchema);
module.exports = purchaseOrder;
module.exports.methods = methods;
