const userService = require("../services/user");
const jwttoken = require('../utils/jwttoken')

const userController = {
  addDemoUser: async (req,res) => {
    try {
      req.body.username="test";
      req.body.userrole="admin";
     const jwtResponse = jwttoken(req);
     res.send({
      message:"Token created successfully",
      token:jwtResponse,
      status:200
     })
    } catch (error) {
      res.send(
        {
          message:`Failed - ${error}`
        }
      )
    }
    
  },
  addUser: async (req, res) => {
    const serviceResponse = await userService.addUser(req, res);
    res.send(serviceResponse);
  },

};
module.exports = userController;
