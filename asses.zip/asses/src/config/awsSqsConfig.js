const awsSqsConfig = {
    region:"eu-north-1",
    credentials  :{
        accessKeyId:"AKIAQ3EGRFUQ5DLDMSUI",
        secretAccessKey:"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"
    }
}

module.exports = awsSqsConfig;