const mongoose = require("mongoose");

// MongoDB connection URL
const localURL = "mongodb://localhost:27017/batch-poc-local"
// const localURL  = "mongodb+srv://peterkhalkotest:0nR0QMzhav71kukY@cluster0.1sbpb1j.mongodb.net/batch-poc?retryWrites=true&w=majority";

// Connect to MongoDB
mongoose.connect(localURL, {})
  .then(() => console.log(`Connected to MongoDB using ${localURL}`))
  .catch(error => console.error("Error connecting to MongoDB:", error));

// Export the mongoose object
module.exports = mongoose;

