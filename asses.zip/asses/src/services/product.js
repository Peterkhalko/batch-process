const productModel = require("../models/product");
const category = require("../models/category");
const awsSQSUtil = require('../utils/awsSqsUtil');
const product = require("../models/product");
const { ObjectId } = require("mongodb");
const proeductService = {
  addProduct: async (req, res) => {
    let acceptedProducts = [];
    let rejectedProducts = [];
    const result = {};

    try {
      if (!Array.isArray(req.body) || req.body.length === 0 || req.body === undefined) {
        result.status = 400;
        result.message = "product array not provided!";
        return result;
      }
      for (let product of req.body) {
        if (!product.productname) {
          rejectedProducts.push(product)
        }
        else if (!product.categoryid) {
          rejectedProducts.push(product)
        }
        else if (!product.createdby) {
          rejectedProducts.push(product)
        }
        else if (!product.price) {
          rejectedProducts.push(product)
        }
        else if (!product.unit) {
          rejectedProducts.push(product)
        }
        else if (!product.quantity) {
          rejectedProducts.push(product)
        }

        else {
          req.body.customquery = { _id: new ObjectId(product.categoryid) }
          const categoryExistsCheck = await category.methods.findCategory(req);
          if (
            categoryExistsCheck.length == 0 ||
            categoryExistsCheck[0]?.isActive == false
          ) {
            rejectedProducts.push(product)

          } else {
            acceptedProducts.push(product)
          }
        }
      }
      //SQS queue utitlity
      const sqsresponse = await awsSQSUtil(acceptedProducts)
      console.log("sqsresponse",sqsresponse)
      if (sqsresponse.MessageId) {
        result.status = 200;
        result.message = "product uploaded",
        result.acceptedProducts = acceptedProducts
        result.acceptedProductsCount = acceptedProducts.length
        result.rejectedProducts = rejectedProducts;
        result.rejectedProductsCount = rejectedProducts.length
        return result;
      }else{
        throw new Error('unable to upload products')
      } 
    } catch (error) {
      console.log("errror", error)
      result.status = 500;
      result.message = `something went bad!`;
      result.data = `error message : ${error.message}`;
      return result;
    }
  },
  getProduct: async (req, res) => {
    const result = {};
    try {
      const modelResponse = await productModel.methods.getProduct(req, res);
      if (modelResponse.length > 0) {
        result.status = 200;
        (result.message = "product fetched successfully!"),
          (result.data = modelResponse);
        result.count = modelResponse.length;

        return result;
      } else {
        result.status = 200;
        (result.message = "No product fetched!"),
          (result.data = modelResponse);
        result.count = modelResponse.length;
        return result;
      }
    } catch (error) {
      result.status = 500;
      result.message = `something went bad!`;
      result.data = `error message : ${error.message}`;
      return result;
    }
  },
  updateProduct: async (req, res) => {
    const result = {};
    try {
      if (!req.body.productid) {
        result.status = 400;
        result.message = "productid not provided!";
        return result;
      }

      const modelResponse = await productModel.methods.updateProduct(req, res);
      if (modelResponse) {
        result.status = 200;
        (result.message = "product updated successfully!"),
          (result.data = modelResponse);
        result.count = modelResponse.length;

        return result;
      } else {
        result.status = 200;
        (result.message = "No product udpated!"),
          (result.data = modelResponse);
        return result;
      }
    } catch (error) {
      result.status = 500;
      result.message = `something went bad!`;
      result.data = `error message : ${error.message}`;
      return result;
    }
  },

  deleteProduct: async (req, res) => {
    const result = {};
    try {
      if (!req.params.productid) {
        result.status = 400;
        result.message = "productid not provided!";
        return result;
      }

      const modelResponse = await productModel.methods.deleteProduct(req, res);
      if (modelResponse) {
        result.status = 200;
        (result.message = "product deleted successfully!"),
          (result.data = modelResponse);
        return result;
      }
      if (!modelResponse) {
        result.status = 404;
        (result.message = "unable to delete product!")
        return result;
      }
    } catch (error) {
      result.status = 500;
      result.message = `something went bad!`;
      result.data = `error message : ${error.message}`;
      return result;
    }
  },
  manageProduct: async (req, res) => {
    const result = {};
    try {
      if (!req.body.actiontype) {
        result.status = 400;
        result.message = "actiontype not provided!";
        return result;
      }
      if (!req.body.quantity) {
        result.status = 400;
        result.message = "quantity not provided!";
        return result;
      }
      if (!req.params.productid) {
        result.status = 400;
        result.message = "productid not provided!";
        return result;
      }

      const modelResponse = await productModel.methods.manageProduct(req, res);
      if (modelResponse) {
        result.status = 200;
        (result.message = "product updated successfully!"),
          (result.data = modelResponse);
        return result;
      }
      if (!modelResponse) {
        result.status = 404;
        (result.message = "unable to update product!"),
          (result.data = modelResponse);
        return result;
      }
    } catch (error) {
      result.status = 500;
      result.message = `something went bad!`;
      result.data = `error message : ${error.message}`;
      return result;
    }
  },
};
module.exports = proeductService;
