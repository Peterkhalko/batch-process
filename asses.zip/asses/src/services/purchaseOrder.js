const { ObjectId } = require("bson");
const purchaseOrderModel = require("../models/purchaseorder");
const productModel = require("../models/product");
const db = require('../config/dbConnection')
const mongoose = require('mongoose')
const purchaseOrderService = {
  createOrders: async (req, res) => {
    const result = {};
    const orderMap = req.body;
    const ordersDataSets = [];
    const ordersRejectedDataSets = [];
    const ordersInsertedLookupDataSets = [];
    const ordersRejectedLookupDataSets = [];
    const modelResponse = [];
    try {
      if (!Array.isArray(orderMap) || orderMap.length === 0) {
        result.status = 400;
        result.message = "found empty orders!";
        return result;
      }
      for (const order of orderMap) {
        const session = await mongoose.startSession();
        session.startTransaction();
        try {
          if (!order.categoryid) {
            result.status = 400;
            result.message = "category name not provided!";
            throw result;
          }
          if (!order.createdby) {
            result.status = 400;
            result.message = "createdby is not provided!";
            throw result;
          }
          if (!order.quantity) {
            result.status = 400;
            result.message = "quantity is not provided!";
            throw result;
          }
          if (!order.productid) {
            result.status = 400;
            result.message = "productid is not provided!";
            throw result;
          }
          const productAvailibilityCheck = await productModel.findById(
            new ObjectId(order.productid)
          );
          if (
            productAvailibilityCheck &&
            productAvailibilityCheck.quantity >= order.quantity
          ) {
            const productModelResponse = await productModel.findOneAndUpdate(
              { _id: new ObjectId(order.productid) }, // Filter criteria
              { $inc: { quantity: -order.quantity } }, // Update operation
              { new: true, session } // Options including the session
            );

            const payload = {
              categoryid: new ObjectId(order.categoryid),
              productid: order.productid,
              quantity: order.quantity,
              createdby: new ObjectId(order.createdby),
            };
            ordersDataSets.push(payload);
            const purchaseOrderModelRsponse = await purchaseOrderModel.create([payload], { session });
            modelResponse.push(...purchaseOrderModelRsponse);
            await session.commitTransaction();
          } else {
            ordersRejectedDataSets.push(order);
          }
        } catch (error) {
          throw error;
        } finally {
          (await session).endSession();
        }
      }
      if (ordersRejectedDataSets.length > 0) {
        for (const order of ordersRejectedDataSets) {
          req.body.customquery = { _id: new ObjectId(order.productid) };
          const response = await productModel.methods.getProduct(req, res);
          ordersRejectedLookupDataSets.push(...response);
        }
      }
      if (modelResponse.length > 0) {
        for (const order of modelResponse) {
          req.body.customquery = { _id: new ObjectId(order._id) };
          const response = await purchaseOrderModel.methods.getOrders(req, res);
          ordersInsertedLookupDataSets.push(...response);
        }
        result.status = 200;
        (result.message = "oreder created successfully!"),
          (result.acceptedorders = ordersInsertedLookupDataSets);
        result.rejectedorders = ordersRejectedLookupDataSets;
        result.acceptedorderscount = ordersInsertedLookupDataSets.length || 0
        result.rejectedorderscount = ordersRejectedLookupDataSets.length || 0

        return result;
      } else {
        result.status = 200;
        (result.message = "unable to create orders"),
          (result.acceptedorders = modelResponse);
        result.rejectedorders = ordersRejectedLookupDataSets;
        result.acceptedorderscount = modelResponse.length || 0
        result.rejectedorderscount = ordersRejectedLookupDataSets.length || 0
        return result;
      }
    } catch (error) {
      result.status = 500;
      result.data = `error message : ${error.message}`;
      result.message = `something went bad!`;
      return result;
    }
  },
  getOrders: async (req, res) => {
    const result = {};
    try {
      const modelResponse = await purchaseOrderModel.methods.getOrders(req, res);
      if (modelResponse.length > 0) {
        result.status = 200;
        (result.message = "orders fetched successfully!"),
          (result.data = modelResponse);
        result.count = modelResponse.length;

        return result;
      } else {
        result.status = 200;
        (result.message = "No orders fetched!"),
          (result.data = modelResponse);
        result.count = modelResponse.length;
        return result;
      }
    } catch (error) {
      console.log("error",error)
      result.status = 500;
      result.message = `something went bad!`;
      result.data = `error message : ${error.message}`;
      return result;
    }
  },
  updateOrders: async (req, res) => {
    const result = {};
    console.log(req.body, req.params)
    if (!req.params.orderid) {
      result.status = 400;
      result.message="order id not provided";
      return result;
    }
    if (!req.params.status) {
      result.status = 400;
      result.message="new order status not provided";
      return result;
    }
    try {
      const modelResponse = await purchaseOrderModel.methods.updateOrders(req, res);
      if (modelResponse) {
        result.status = 200;
        (result.message = "orders updated successfully!"),
          (result.data = modelResponse);
        result.count = modelResponse.length;
        return result;
      } else {
        result.status = 200;
        (result.message = "No orders updated!"),
          (result.data = modelResponse);
        result.count = modelResponse.length;
        return result;
      }
    } catch (error) {
      console.log("error",error)
      result.status = 500;
      result.message = `something went bad!`;
      result.data = `error message : ${error.message}`;
      return result;
    }
  },
};
module.exports = purchaseOrderService;
