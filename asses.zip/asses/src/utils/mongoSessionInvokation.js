
const mongoSessionTrigger = () => {
    const MongoClient = require('mongodb').MongoClient;
    const localURL = process.env.MONGODB_URI || 'mongodb://localhost:27017/batch-db';
    const client = new MongoClient(localURL);
    async function connectToDatabase() {
        await client.connect();
    }
    connectToDatabase().catch(console.error);
    return client;
}
module.exports = mongoSessionTrigger();