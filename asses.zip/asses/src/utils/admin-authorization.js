const jwt = require('jsonwebtoken');
  const  adminAuthorization = (req, res, next) => {
    console.log("req in admin auth",req.headers["authorization"]);
      const token =
        req.body.token || req.query.token || req.headers["authorization"];
        const secretKey = process.env.assesment_secrete_key|| 'assesment_secrete_key_peterkhalko';

      if (token) {
        jwt.verify(token, secretKey, (err, decoded) => {
          if (err) {
            console.log("in the  error",err)
            return res.send({
              success: false,
              message: "Failed to authenticate token.",
              status:401
            });
          } else {
            console.log("decoded ", decoded);
            if (decoded.userrole !== 'admin') {
              return res.send({
                success: false,
                message: "Unauthorized access! contact admin",
                status:403
              });
            }else{
              next();

            }
          }
        });
      } else {
        return res.status(403).send({
          success: false,
          message: "No token provided.",
          status:403
        });
      }

    }
module.exports = adminAuthorization