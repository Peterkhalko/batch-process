const {SQSClient,SendMessageCommand} = require('@aws-sdk/client-sqs');
const awsSqsConfig = require('../config/awsSqsConfig');
const sqs = new SQSClient(awsSqsConfig);
const queueURL = "https://sqs.eu-north-1.amazonaws.com/058264202529/batch-queue";
const createMessageToQueue = async (payload) =>{
        try {
            const command = new SendMessageCommand({
                MessageBody: JSON.stringify(payload),
                QueueUrl:queueURL, 
            })
            const result = await sqs.send(command);
            return result;
        } catch (error) {
            console.log(error);
            throw error;
        }
}
module.exports = createMessageToQueue;