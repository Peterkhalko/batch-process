import mongoose from "mongoose";
export const handler = async (event) => {
//   const mongourl = process.env.MONGOURL;
  const mongourl = "mongodb+srv://peterkhalkotest:0nR0QMzhav71kukY@cluster0.1sbpb1j.mongodb.net/batch-poc?retryWrites=true&w=majority";
  try {
    // Connect to MongoDB
    await mongoose.connect(mongourl, {});
    console.log("db connection successful");

    // Perform database operations
    const data = JSON.parse(event.Records[0].body);
    const response = await mongoose.connection.collection("products").insertMany(data);
    console.log("response", response);

    return response;
  } catch (error) {
    console.error("Error connecting to MongoDB:", error);
    throw error; // rethrow the error to be caught by AWS Lambda
  }
};
